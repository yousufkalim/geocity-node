const Joi = require("joi");
const asyncHandler = require("../middlewares/async");
const User = require("../models/User");
const Project = require("../models/Project");
const Material = require("../models/Material");
const Skill = require("../models/Skill");
const Category = require("../models/Category");
var ObjectID = require("mongodb").ObjectID;

//REGISTER USER API

exports.register = asyncHandler(async (req, res, next) => {
  try {
    const skills1 = JSON.parse(req.body.skills);
    const material1 = JSON.parse(req.body.material);
    // ****
    // const materialCheck = material1.find((dt) => typeof dt === typeof "");
    // var objectId = new ObjectID();
    // var index = material1.indexOf(materialCheck);

    // if (index !== -1) {
    //   material1[index] = `${objectId}`;
    // }
    //
    const body = req.body;
    body.skills = skills1;
    body.material = material1;
    if (req.file) {
      var uploaded_Picture = req.file.filename;
    }

    // Validation
    const nestedSchema = Joi.object().keys({
      skillField: Joi.string().required(),
      skill: Joi.string().required(),
      specialization: Joi.string().allow(""),
      score: Joi.string()
        .max(5)
        .pattern(/^[0-5]+$/)
        .required(),
    });
    const schema = Joi.object().keys({
      username: Joi.string().required(),
      firstName: Joi.string().required(),
      lastName: Joi.string().required(),
      facebook: Joi.string().uri().allow(""),
      instagram: Joi.string().uri().allow(""),
      youtube: Joi.string().uri().allow(""),
      email: Joi.string().max(255).email(),
      city: Joi.string(),
      zipCode: Joi.string(),
      latitude: Joi.string(),
      longitude: Joi.string(),
      password: Joi.string().min(6).max(255),
      availability: Joi.string(),
      confirm_password: Joi.string().min(6).max(255),
      profile_picture: Joi.string().max(255),
      profile_description: Joi.string().min(10).max(600),
      phone: Joi.string()
        .max(10)
        .pattern(/^[0-9]+$/)
        .required(),
      skills: Joi.array().max(3).items(nestedSchema),
      material: Joi.array().max(50).min(1).items(Joi.string()),
    });

    const results = schema.validate(body);
    if (results.error) {
      return res.status(400).send(results.error.details[0].message);
    }

    const {
      username,
      firstName,
      lastName,
      facebook,
      instagram,
      youtube,
      email,
      city,
      zipCode,
      latitude,
      longitude,
      password,
      availability,
      confirm_password,
      profile_picture,
      profile_description,
      phone,
      skills,
      material,
      notifications,
    } = req.body;

    // Check if the skills are in database or not, If Not then saving them in the database//
    if (skills) {
      skills.map(async (val) => {
        let result = false;
        var requestedSkill = val.skill;
        var savedSkillField = await Skill.findById(val.skillField);
        savedSkillField.skill.map(async (val1) => {
          if (requestedSkill == val1) {
            result = true;
          }
        });

        if (result == false) {
          await Skill.findByIdAndUpdate(val.skillField, {
            $push: { skill: requestedSkill },
          });
        }
      });
    }

    //// Check If Password and Confirm Password are same or not ////
    if (password !== confirm_password) {
      res.status(403).send("Password and Confirm Password are not same");
    }

    //// Check If user exist with this Email or not ////

    const result = await User.findOne({ email: email });
    if (result) {
      res.status(404).send("User already registered with this Email Address");
    } else {
      // Saving User in DataBase
      const user = await User.create({
        username,
        firstName,
        lastName,
        facebook,
        instagram,
        youtube,
        email,
        city,
        zipCode,
        latitude,
        longitude,
        password,
        availability,
        profile_picture: uploaded_Picture || "default.png",
        profile_description,
        phone,
        skills,
        material,
        notifications,
      });
      res.status(200).json({ user: user });
    }
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

//Login User
exports.login = asyncHandler(async (req, res, next) => {
  const { email, password } = req.body;

  const schema = Joi.object().keys({
    email: Joi.string().max(40).required().email(),
    password: Joi.string().min(6).max(255).required(),
  });

  const results = schema.validate(req.body);
  if (results.error) {
    return res.status(400).send(results.error.details[0].message);
  }

  //validating email and password
  if (!email || !password) {
    return res.status(400).send("please provide email and password");
  }

  //check for user
  const user = await User.findOne({ email: email }).select("+password");
  if (!user) {
    return res.status(400).send("You are not registered please signup");
  }

  // Check if password matches

  const isMatch = await user.matchPassword(password);

  if (!isMatch) {
    return res.status(400).send("Password is Invalid");
  }

  sendTokenResponse(user, 200, res);
});

//Get token from Model create cookie and send response

const sendTokenResponse = (user, statusCode, res) => {
  //create token

  const token = user.getSignedJwtToken();

  const options = {
    expires: new Date(
      Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000
    ),
    httpOnly: true,
  };

  if (process.env.NODE_ENV === "production") {
    options.secure = true;
  }
  if (user) {
    res.status(statusCode).cookie("token", token, options).json({
      token: token,
      user: user,
    });
  } else {
    res.send("Something went wrong");
  }
};

// USER Logout
exports.logout = asyncHandler(async (req, res, next) => {
  req.session.destroy(() => {
    req.logOut();
    res.clearCookie("token");
    res.status(200).send("Logged out successfully");
  });
});

// GET ALL PROJECTS //
exports.ProjectsList = asyncHandler(async (req, res, next) => {
  let projectsArray = [];
  const projects = await Project.find({ isDeleted: false }).populate(
    "category"
  );
  if (projects) {
    projects.map((item) => {
      const likes = item.likedBy.length;
      projectsArray.push({ project: item, totalLikes: likes });
    });
    res.status(200).json({ projects: projectsArray });
  } else {
    res.status(200).json({ projects: "No projects yet" });
  }
});

// get All Categories
exports.CategoryList = asyncHandler(async (req, res, next) => {
  await Category.find({ isDeleted: false }, function (err, docs) {
    if (err) res.json(err);
    else
      res.status(200).json({
        category: docs,
      });
  });
});

// get All SKILLS
exports.SkillList = asyncHandler(async (req, res, next) => {
  await Skill.find({ isDeleted: false }, function (err, docs) {
    if (err) res.json(err);
    else
      res.status(200).json({
        skills: docs,
      });
  });
});

// Get All Materials //
exports.MaterialList = asyncHandler(async (req, res, next) => {
  await Material.find({ isDeleted: false }, function (err, docs) {
    if (err) res.json(err);
    else
      res.status(200).json({
        materials: docs,
      });
  });
});
